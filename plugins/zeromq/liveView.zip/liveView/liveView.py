'''
  This file is part of the PyPhantomJS project.

  Copyright (C) 2011 James Roe <roejames12@hotmail.com>

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os

from PyQt4 import uic
from PyQt4.QtCore import pyqtProperty, pyqtSlot, QObject, QSize

from plugincontroller import add_action, get, set_


class UiWrapper(QObject):
    '''Limit the API calls available to the Ui object'''
    def __init__(self, parent, ui):
        super(UiWrapper, self).__init__(parent)

        self.m_parent = parent
        self.ui = ui

    @pyqtSlot()
    def show(self):
        self.ui.show()

    @pyqtSlot()
    def close(self):
        # we're hiding the widget instead of closing,
        # because closing it kills the program
        self.ui.hide()

@pyqtProperty(UiWrapper)
def liveView(self):
    return self.uiWrapper


@add_action('WebPageInit')
def initiate():
    self = get('self')

    self.ui = uic.loadUi(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources/webpage.ui'))
    self.uiWrapper = UiWrapper(self, self.ui)
    self.ui.webView.setPage(self.m_webPage)

    def onUrlChange(url):
        self.ui.lineEditUrl.setText(url.toString())
        self.ui.setWindowTitle('%s - PyPhantomJS' % url.host())

    self.ui.setWindowTitle('%s - PyPhantomJS' % self.m_mainFrame.url().host())
    self.ui.webView.setFixedSize(self.m_webPage.viewportSize())

    self.m_mainFrame.urlChanged.connect(onUrlChange)
    self.m_webPage.repaintRequested.connect(lambda: self.ui.webView.setFixedSize(self.m_webPage.viewportSize()))

    # reset webPage to default size
    self.m_webPage.setViewportSize(QSize(400, 300))

@add_action('WebPage')
def run():
    set_('liveView', liveView)
