'''
  This file is part of the PyPhantomJS project.

  Copyright (C) 2011 James Roe <roejames12@hotmail.com>

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os

from plugincontroller import add_action

# load up the libraries
@add_action('PhantomInitPost')
def inject_libs(_locals):
    oldPath = _locals.self.libraryPath
    _locals.self.libraryPath = os.path.abspath(os.path.join(os.path.dirname(__file__), 'lib'))

    _locals.self.injectJs('require-kiss.js')
    _locals.self.injectJs('overrides.js')

    _locals.self.libraryPath = oldPath
